﻿namespace CustomComparator
{
    using System;

    internal class StartUp
    {
        static void Main()
        {
            int[] nums = { 3,4,1,2 };

            Array.Sort(nums, new CustomComparator());

            Console.WriteLine(String.Join(" ",nums));
        }
    }
}
