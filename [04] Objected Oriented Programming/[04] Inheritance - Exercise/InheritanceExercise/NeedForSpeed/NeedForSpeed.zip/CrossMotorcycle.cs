﻿namespace NeedForSpeed
{
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsepowers, double fuel) 
            : base(horsepowers, fuel)
        {
        }
    }
}
