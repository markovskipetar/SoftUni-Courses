﻿namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horsepowers, double fuel) 
            : base(horsepowers, fuel)
        {
        }
    }
}
