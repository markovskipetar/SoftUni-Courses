﻿namespace NeedForSpeed
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int horsepowers, double fuel) 
            : base(horsepowers, fuel)
        {
        }
    }
}
