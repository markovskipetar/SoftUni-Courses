﻿using System;

namespace Assd
{
    internal class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
