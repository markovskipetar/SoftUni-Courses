﻿namespace PizzaCalories
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();

            engine.Start();
        }
    }
}
