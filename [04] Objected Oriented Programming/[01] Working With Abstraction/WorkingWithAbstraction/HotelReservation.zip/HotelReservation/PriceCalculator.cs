﻿using System;

namespace HotelReservation
{
    class PriceCalculator
    {
        enum PricePerDayMultiplier
        {
            Autumn = 1,
            Spring = 2,
            Winter = 3,
            Summer = 4,
        }

        enum Discounts
        {
            SecondVisit = 10,
            VIP = 20,
        }

        public void GetTotalPrice(string[] inputData)
        {
            decimal pricePerDay = decimal.Parse(inputData[0]);
            int daysCount = int.Parse(inputData[1]);
            string season = inputData[2];
            double discountMultiplier = 1;

            int pricePerDayMultiplier = GetPricePerDayMultiplier(season);
            pricePerDay *= pricePerDayMultiplier;

            if (inputData.Length == 4)
            {
                string discountType = inputData[3];

                discountMultiplier = GetDiscountMultiplier(discountType);
            }

            decimal totalPrice = CalculateFinalPrice(pricePerDay, daysCount, discountMultiplier);

            Console.WriteLine($"{totalPrice:f2}");
        }

        public int GetPricePerDayMultiplier(string season)
        {
            switch (season)
            {
                case "Winter":
                    return (int)PricePerDayMultiplier.Winter;
                case "Spring":
                    return (int)PricePerDayMultiplier.Spring;
                case "Summer":
                    return (int)PricePerDayMultiplier.Summer;
                default:
                    return 1;
            }
        }

        public double GetDiscountMultiplier(string discountType)
        {
            double discountMultiplier = 0;

            switch (discountType)
            {
                case "VIP":
                    discountMultiplier = (100 - (int)Discounts.VIP) / 100.0;
                    break;

                case "SecondVisit":
                    discountMultiplier = (100 - (int)Discounts.SecondVisit) / 100.0;
                    break;
            }

            return discountMultiplier;
        }

        public decimal CalculateFinalPrice(decimal pricePerDay, int daysCount, double discountMultiplier)
        {
            decimal total = (pricePerDay * daysCount) * (decimal)discountMultiplier;

            return total;
        }
    }
}
